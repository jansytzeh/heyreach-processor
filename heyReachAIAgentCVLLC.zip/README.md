# HeyReach AI Follow-Up System

Automated LinkedIn conversation handler for CazVid and Agency Leads campaigns.

## Quick Start

1. Open a terminal in this folder
2. Run `claude` to start Claude Code
3. Use the commands below

## Commands

| Command | What It Does |
|---------|--------------|
| `/process-heyreach` | Process unread conversations and send follow-ups |
| `/train-heyreach` | Train the AI (9 modes: review, learn, score, outcomes) |
| `/recommend` | Get AI-powered training recommendations |
| `/troubleshoot` | Diagnose and fix errors from command runs |
| `/metrics` | Generate aggregated stats from run logs |
| `/update-config` | Change settings (fetch limit, messages per run) |
| `/update-lead-samples` | Update the 3 lead samples for Agency Leads (auto or manual) |

## Typical Workflow

**Daily:**
```
/process-heyreach
```
Select response type → choose Live or Dry-Run → confirm count → done.

**Weekly:**
```
/train-heyreach
/metrics
/update-lead-samples
```
Review tagged conversations, check metrics, refresh lead samples.

## Run Modes

| Mode | Description |
|------|-------------|
| **Live** | Send messages for real |
| **Dry-Run** | Preview messages without sending (safe testing) |

All commands include a **health check** - if MCP tools are unavailable, you'll be notified to restart your session.

## Response Types

- **CazVid Thank-You** (Spanish/English) - "gracias", "thanks"
- **CazVid Info Request** (Spanish/English) - "how does this work?"
- **Agency Leads Decline** - "not interested"
- **Agency Leads Sample Request** - "send me samples"

## Training System

The AI improves through a structured 5-level curriculum:

| Level | Focus | Goal |
|-------|-------|------|
| 1 | Foundation | 95% trigger accuracy |
| 2 | Exclusions | 90% edge case handling |
| 3 | Personalization | Natural, varied messages |
| 4 | Context | Deep personalization |
| 5 | Mastery | 25% conversion rate |

**Training Modes:** Review tagged, Learn from Jan, Score quality, Track outcomes, A/B testing

**Run `/recommend`** to see what to train on next.

## Tagging in HeyReach

Tag conversations to train the AI:

### Handling Tags
| Tag | When to Use |
|-----|-------------|
| `AI Input` | AI handled this conversation |
| `Manual Handled Jan` | Jan handled manually |
| `Bad AI Handling` | AI made a mistake (always tag these!) |
| `Good AI Handling` | AI did well on a tricky case |

### Outcome Tags
| Tag | When to Use |
|-----|-------------|
| `Positive Outcome` | Prospect responded positively |
| `Converted` | Booked meeting or took action |
| `Negative Outcome` | Not interested |

## Files

```
/config.md                 - Main configuration and templates
/.claude/commands/         - Slash command definitions
/training/                 - Training data and logs
```

## Settings

Edit in `/update-config` or directly in `config.md`:

- **FETCH_LIMIT**: Conversations to fetch (default: 10, max: 100)
- **MAX_MESSAGES_TO_SEND**: Messages per run (default: 10)

## Troubleshooting

If a command fails:

1. Run `/troubleshoot`
2. Select "Diagnose Active Errors" (Mode 1)
3. Follow the guided resolution

Errors are automatically logged to `training/error-registry.md` with status tracking.
