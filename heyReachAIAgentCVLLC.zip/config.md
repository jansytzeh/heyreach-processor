# HeyReach Configuration

## Settings

| Setting | Value | Description |
|---------|-------|-------------|
| **FETCH_LIMIT** | `99` | Conversations to fetch per run (API max: 100, but 10-25 recommended to avoid overflow) |
| **MAX_MESSAGES_TO_SEND** | `30` | Messages to send per run |

### Agency Leads 3 Lead Sample (Update Weekly)

| Variable | Value |
|----------|-------|
| **LEAD_SAMPLE_1** | `Senior Legal Personal Assistant: Mishcon de Reya LLP - Cambridge, United Kingdom` |
| **LEAD_SAMPLE_2** | `Associate Attorney: Feldman Jackson, PC - Bethesda, Maryland` |
| **LEAD_SAMPLE_3** | `Executive Assistant to SVP of Legal: Rush University Medical Center - Chicago, Illinois` |

---

## Response Philosophy

**IMPORTANT: Follow the templates closely.** Variation should be in wording, NOT in omitting required elements. Every response MUST include all required links and CTAs.

### Core Principles
1. **Match their energy** - If they're enthusiastic (!!!), be enthusiastic back
2. **Be conversational** - Write like a real person, not a bot
3. **Vary your openings** - Don't start every message the same way
4. **ALWAYS include required elements** - Links and CTAs are MANDATORY, never optional
5. **Personalize beyond name** - Reference their context when possible
6. **Never fabricate context** - Only reference what they actually said
7. **Fix name capitalization** - Use "Patricia" not "PATRICIA" (normalize from source data)
8. **Match their brevity** - Short message = short response. Don't dump 50 words on a 4-word message

### Energy Matching Rules (MEASURABLE)

**Length Calibration:**
| Their Message | Your Target | Example |
|---------------|-------------|---------|
| 1-10 words | 15-25 words | "Gracias" → "¡Gracias a ti! ¿Qué te parecieron?" |
| 11-25 words | 25-50 words | Standard response with links |
| 26-50 words | 50-75 words | Fuller explanation OK |
| 50+ words | Full template | They're engaged, give details |

**Enthusiasm Detection:**
| Signal | They're... | Match With |
|--------|-----------|------------|
| `!!!` or `!!!` | Very excited | Add `!` to your response, upbeat language |
| `???` | Confused/curious | Clear, helpful tone |
| ALL CAPS words | Emphatic | Mirror their energy (sparingly) |
| Emojis | Casual/friendly | Warm, conversational tone |
| No punctuation | Minimal effort | Keep it brief and direct |

**Examples:**

❌ **BAD (José case):**
```
Him: "Emile, como estás!!! Muchas gracias. Ya cerramos el proceso. Te agradezco enormemente."
AI: "De nada, José. ¿Tienes otras vacantes?"
```
↑ WRONG: He used !!! and "enormemente" - he's enthusiastic. AI was flat.

✅ **GOOD:**
```
Him: "Emile, como estás!!! Muchas gracias. Ya cerramos el proceso. Te agradezco enormemente."
AI: "¡Qué bueno José! Me alegra mucho. ¿Hay otras vacantes que te gustaría llenar?"
```

❌ **BAD (Olga case):**
```
Her: "es gratis la publicacion?" (5 words)
AI: "¡Sí Olga, publicar tu vacante es gratis! CazVid te permite publicar gratis y explorar candidatos. Solo pagas $50 USD/mes cuando quieras contactarlos directamente..." (50+ words)
```
↑ WRONG: 5 words in, 50 words out = energy mismatch

✅ **GOOD:**
```
Her: "es gratis la publicacion?" (5 words)
AI: "¡Sí, es gratis! Solo pagas cuando quieras contactar candidatos. Publica aquí: [link]" (15 words)
```

### CRITICAL GUARDRAILS (Never Violate)
- **NEVER claim candidates have features they don't have** (e.g., "video profile", "video resume")
- **NEVER claim contacting candidates is FREE** - It requires a $50/month subscription
- **NEVER skip the job posting link** - It is the primary conversion goal
- **NEVER skip the YouTube tutorial** - It teaches them how to use the platform
- **NEVER invent different CTAs** - Use the specified CTA format ("Which candidate would you like me to connect you with?")
- **If unsure, use the standard template** - Don't improvise

### CazVid Pricing Truth (NEVER Misrepresent)
| What's FREE | What's PAID |
|-------------|-------------|
| Posting a job | Contacting candidates ($50/month) |
| Browsing candidates | Sending messages to candidates |
| Viewing video overviews | Accessing contact info |
| Receiving applications | - |

**Correct framing:** "Free to post, free to browse, subscription when you're ready to contact"
**WRONG:** "Contacting candidates is free" ← This is FALSE and damages trust

### What Happens When You Post a Job (Use This, Don't Invent)
- We send your job to the **top 100 matching candidates**
- Candidates apply and you **receive resumes by email**
- You can browse candidates and view their profiles for FREE
- When you find the perfect person, subscribe to contact them

**WRONG claims to avoid:**
- "We'll automatically match them with our database" ← vague/incorrect
- "I can help you find the best matches" ← we don't manually match, candidates apply

---

## Response Types

| Type | Language | Triggers |
|------|----------|----------|
| CazVid Thank-You | Spanish | gracias, muchas gracias, mil gracias |
| CazVid Thank-You | English | thanks, thank you, thx |
| CazVid Info Request | Spanish | cómo funciona, más información, cuánto cuesta |
| CazVid Info Request | English | how does it work, tell me more, what's the cost |
| Agency Leads Decline | Both | not interested, no thanks, no gracias |
| Agency Leads Sample | English | send me, yes please, sure, sounds good |
| **Vacancy Closed** | Both | cerré la vacante, position filled, ya cerré |
| **Casual Greeting** | Both | hola (alone), hello (alone), how are you |
| **CV/Email Request** | Both | envíame los CVs, send me CVs, send to my email |
| **Location Objection** | Both | estamos en [city], we are based in, candidatos de [city] |
| **PDF Request** | Both | PDF + (send/enviar/mandar/want/quiero/need/necesito) |
| **LinkedIn Profile Request** | Both | linkedin + (share/give/send/access/verify/verificar) |
| **Language Switch Request** | English | communicate in English, speak English, in English please, do you speak English |

---

## Already Processed Detection

Skip conversations where we already sent these patterns:

| Response Type | Detection Pattern |
|---------------|-------------------|
| CazVid Thank-You (ES) | "share.cazvid.app" in our message |
| CazVid Thank-You (EN) | "share.cazvid.app" in our message |
| CazVid Info Request (ES) | "$50 USD" OR "50 dólares" |
| CazVid Info Request (EN) | "$50 USD/month" OR "post your job for free" |
| Agency Leads Decline | "timing, fit, or need" |
| Agency Leads Sample | "lead sample" OR "3 quick examples" |
| Vacancy Closed | "otras vacantes" OR "other positions" |
| Casual Greeting | "currently hiring" OR "estás contratando" |
| CV/Email Request | "publica tu vacante" + redirect context |
| Location Objection | "Post your job on CazVid" OR "Publica tu vacante en CazVid" |
| PDF Request | "Contact Now" button" OR "Contactar Ahora" |
| LinkedIn Profile Request | "LinkedIn profiles directly" OR "perfiles de LinkedIn directamente" |
| Language Switch Request | "Happy to continue in English" OR "Of course" + English switch |

---

## Response Guidelines

### CazVid Thank-You (Spanish)

**Triggers:** gracias, muchas gracias, mil gracias, te agradezco

**Tone:** Warm, helpful, casual-professional

**Required Elements:**
- Acknowledge their thanks (vary the phrase!)
- Their first name (use naturally, not robotically)
- Free job posting link: `https://share.cazvid.app/cazvid3.0/es/free-job-posting?utm_source=linkedin&utm_medium=message&utm_campaign=[Sender Last Name]&utm_content=candidate`
- YouTube tutorial: `https://youtu.be/c0E8sfSFqeM`
- CTA asking which candidate to connect with

**Opening Variations (pick one, or create your own):**
- "De nada [Name],"
- "¡Con gusto [Name]!"
- "¡Perfecto [Name]!"
- "¡Me alegra que te sirva, [Name]!"
- "¡Claro que sí, [Name]!"

**Message Structure:**
1. Acknowledge thanks (1 sentence)
2. Mention free job posting + share link (1-2 sentences)
3. Share video to help them contact candidates (1 sentence)
4. CTA about connecting with a candidate (question)

**Example Variations:**

*Standard:*
```
De nada María,

Te dejo el enlace para publicar tu vacante gratis: [link]. También te comparto un video corto que te muestra cómo contactar a los candidatos que te envié: [video]

¿Con cuál candidato te gustaría que te conecte?
```

*Enthusiastic (if they used !!! or showed excitement):*
```
¡Con gusto Carlos! Me alegra que te hayan servido los perfiles.

Aquí puedes publicar tu vacante gratis: [link]. Y este video te muestra cómo contactar a los candidatos directamente: [video]

¿Cuál de ellos te llamó más la atención? ¡Te puedo conectar!
```

*Brief (if their message was short):*
```
¡Perfecto Ana!

Publica tu vacante gratis aquí: [link]
Video de cómo contactar candidatos: [video]

¿Con cuál te conecto?
```

*Short/Ambiguous (2-step approach):*

**When to use:** Message is < 15 words, no enthusiasm markers (!!!, "me sirve", "excelente"), no specific mention of candidates/profiles. Examples: "Hola John, te agradezco!", "Gracias"

**Why:** "Te agradezco" in Latin America can mean genuine thanks OR a polite decline. Don't dump a full template on an ambiguous 4-word message.

**Step 1 - Probe first (match their brevity):**
```
¡Gracias a ti! ¿Qué te parecieron los perfiles?
```

**Step 2 - ONLY if they respond positively:** Send the full template with links.

**If they respond negatively/neutral:** Acknowledge gracefully, leave door open:
```
Entendido. Si en el futuro buscas candidatos, aquí estoy. ¡Éxito!
```

---

### CazVid Thank-You (English)

**Triggers:** thanks, thank you, thx, appreciate it, ty

**Tone:** Friendly, professional, helpful

**Required Elements:**
- Acknowledge their thanks (vary the phrase!)
- Their first name
- Free job posting link: `https://share.cazvid.app/cazvid3.0/en/free-job-posting?utm_source=linkedin&utm_medium=message&utm_campaign=[Sender Last Name]&utm_content=candidate`
- YouTube tutorial: `https://youtu.be/mldU26l91ZA`
- CTA asking which candidate to connect with

**Opening Variations:**
- "You're welcome [Name],"
- "Happy to help, [Name]!"
- "Glad they're useful, [Name]!"
- "Of course, [Name]!"
- "My pleasure, [Name]!"

**Example Variations:**

*Standard:*
```
You're welcome Sarah!

Here's where you can post your job for free: [link]. I'm also sharing a quick video on how to reach out to the candidates I sent: [video]

Which candidate would you like me to connect you with?
```

*Conversational:*
```
Happy to help, Mike! Glad the profiles are useful.

Quick tip - you can post your job opening for free here: [link]. And this video shows how to contact the candidates directly: [video]

Any of them catch your eye? I can make an intro!
```

*Short/Ambiguous (2-step approach):*

**When to use:** Message is < 15 words, no enthusiasm markers (!!!, "useful", "great"), no specific mention of candidates/profiles. Examples: "Thanks John!", "Thank you"

**Why:** Short thank-yous can be genuine gratitude OR polite brush-offs. Match their brevity first.

**Step 1 - Probe first (match their brevity):**
```
Thanks! What did you think of the profiles?
```

**Step 2 - ONLY if they respond positively:** Send the full template with links.

**If they respond negatively/neutral:** Acknowledge gracefully, leave door open:
```
No problem! If you ever need candidates, just reach out. Good luck!
```

**BAD Examples (NEVER do this):**
```
You're welcome Saloni! Let me know if any of the Native English Speaker candidates look promising. Each one has a video profile so you can evaluate their communication before reaching out. Would you like me to find more candidates?
```
↑ WRONG because:
- Claims "Each one has a video profile" - **FABRICATED FEATURE**
- Missing job posting link - **REQUIRED ELEMENT OMITTED**
- Missing YouTube tutorial - **REQUIRED ELEMENT OMITTED**
- Wrong CTA - should be "Which candidate would you like me to connect you with?"

---

### CazVid Info Request (Spanish)

**Triggers:** cómo funciona, como funciona, más información, cuánto cuesta, qué es cazvid, explícame

**Tone:** Informative, enthusiastic, helpful

**Required Elements:**
- Acknowledge their question
- Explain: free to post, $50/month to contact candidates
- Value prop: no results = no payment
- Platform intro video: `https://youtu.be/XJZcKKnymcU`
- Free job posting link
- CTA to get started

**Key Points to Convey:**
1. Post job for FREE
2. We send your job to **top 100 matching candidates**
3. Candidates apply → you **receive resumes by email**
4. Browse candidates for FREE
5. $50 USD/month subscription when you want to contact them

**Example:**
```
¡Hola [Name]! Con gusto te explico.

CazVid te permite publicar tu vacante gratis. La enviamos a los 100 mejores candidatos y recibirás sus currículums directamente por correo. Solo pagas $50 USD/mes cuando quieras contactarlos.

Te dejo un video introductorio: [video]

Y aquí puedes publicar tu vacante gratis para empezar: [link]

¿Arrancamos?
```

**BAD Example (NEVER do this):**
```
¡Hola Fredy! No, contactar a los candidatos es completamente gratis. Solo necesitas crear una cuenta gratuita en CazVid y podrás ver sus video-presentaciones y enviarles mensajes directamente.
```
↑ WRONG because:
- Claims "contactar a los candidatos es completamente gratis" - **FALSE, it costs $50/month**
- Claims you can "enviarles mensajes directamente" for free - **FALSE**
- Missing YouTube tutorial link
- Missing job posting link

---

### CazVid Info Request (English)

**Triggers:** how does it work, how does this work, tell me more, what's the cost, what is cazvid, explain

**Tone:** Clear, enthusiastic, helpful

**Required Elements:**
- Same as Spanish version but in English
- Platform intro video: `https://youtu.be/mldU26l91ZA`

**Key Points to Convey:**
1. Post job for FREE
2. We send your job to **top 100 matching candidates**
3. Candidates apply → you **receive resumes by email**
4. Browse candidates for FREE
5. $50/month subscription when you want to contact them

**Example:**
```
Great question, [Name]!

CazVid lets you post your job for free. We'll send it to the top 100 matching candidates and you'll receive their resumes directly by email. You only pay $50/month when you're ready to contact them.

Here's a quick platform intro: [video]

Post your job for free here: [link]

Ready to get started?
```

**BAD Example (NEVER do this):**
```
Awesome Imtiyaz! Once you post your jobs on CazVid, we'll automatically match them with our database of candidates. Let me know when you've posted and I can help you find the best matches for your openings!
```
↑ WRONG because:
- "automatically match them with our database" - **VAGUE/INCORRECT** (we send to top 100, they apply)
- "I can help you find the best matches" - **FALSE** (we don't manually match, candidates apply)
- Missing YouTube tutorial link
- Missing job posting link
- Missing pricing information

---

### Agency Leads Decline (English)

**Triggers:** not interested, no thanks, no thank you, I'm ok, I'm good, pass

**Tone:** Respectful, professional, brief

**Required Elements:**
- Acknowledge respectfully
- Ask for feedback reason (timing/fit/need)
- Promise to tag correctly to avoid future contact

**Key:** Keep it SHORT. Don't be pushy. Get feedback to improve targeting.

**Example Variations:**
```
No problem [Name] - totally understand.

Quick question: was it timing, fit, or just not something you need? I'll tag it so we don't bother you again.
```

```
All good [Name], appreciate you letting me know.

Is it a timing thing, not the right fit, or just not a need? Want to make sure I note it correctly.
```

---

### Agency Leads Decline (Spanish)

**Triggers:** no gracias, no estoy interesado, no me interesa, estoy bien así

**Same approach as English, in Spanish.**

**Example:**
```
Entendido [Name], sin problema.

¿Es por el momento, porque no es lo que necesitas, o simplemente no aplica? Lo anoto para no volver a contactarte.
```

---

### Agency Leads Sample Request

**Triggers:** send me, I'd like to see, yes please, sure, sounds good, let's see, show me

**Tone:** Excited, professional, action-oriented

**Required Elements:**
- Express enthusiasm
- 3 lead samples (use LEAD_SAMPLE_1, LEAD_SAMPLE_2, LEAD_SAMPLE_3)
- Offer demo to show hiring manager details
- Calendly link: `https://calendly.com/agency-leads/agency-leads-premium-staffing-leads-c0100`
- Suggest specific times

**Example:**
```
Awesome [Name]! Here's your sample:

• [LEAD_SAMPLE_1]
• [LEAD_SAMPLE_2]
• [LEAD_SAMPLE_3]

I'd love to show you the hiring managers and their direct contact info in a quick 15-minute demo.

I have openings tomorrow at 11 AM, 2 PM, and 3 PM - which works for you?

Or grab a slot here: [calendly]
```

---

### Vacancy Closed (Both Languages)

**Triggers:** cerré la vacante, cerré vacante, ya cerré, la he completado, position filled, role was closed, we filled the position

**Tone:** Gracious, forward-looking, brief

**Goal:** Don't end the relationship - ask about next opportunity

**Required Elements:**
- Brief acknowledgment (1 short sentence)
- Ask about other open positions
- Keep it SHORT - 2 sentences max

**CRITICAL RULES:**
- **NEVER fabricate context** - Don't assume they kept candidates "en cartera" or any other detail they didn't mention
- **Keep it simple** - Don't embellish or add unnecessary phrases
- **Use proper name capitalization** - "Patricia" not "PATRICIA"

**Example (Spanish):**
```
De nada, [Name]. ¿Hay otras vacantes en el momento que te gustaría llenar?
```

**Example (English):**
```
Glad we could help, [Name]! Do you have any other positions you're looking to fill?
```

**BAD Example (avoid):**
```
¡Me alegra que hayas encontrado a alguien! Y qué bueno que los dejaste en cartera.  ← WRONG: fabricates "en cartera"
```

**Notes:**
- This was previously an EXCLUSION - now we handle it proactively
- Jan's insight: Closed positions = opportunity for next placement
- Lesson learned: Simplicity beats embellishment

---

### Casual Greeting (Both Languages)

**Triggers:**
- Spanish: "hola" (alone, not followed by question)
- English: "hello", "hi", "how are you" (alone, not followed by context)

**Detection:** Message is SHORT (< 20 chars) AND contains only greeting

**Tone:** Friendly, brief, redirect to business

**Goal:** Respond politely, then qualify if they're still hiring

**Required Elements:**
- Brief friendly response
- Redirect question about hiring

**Example (Spanish):**
```
¡Hola [Name]! ¿Sigues buscando candidatos para tu vacante?
```

**Example (English):**
```
Hi [Name], I'm good thanks for asking! You're currently hiring, right?
```

**Notes:**
- Only trigger if message is JUST a greeting (short message)
- If greeting + question, handle the question instead

---

### CV/Email Request (Both Languages)

**Triggers:**
- Spanish: envíame los CVs, mándame los CVs, envía a mi correo, los quiero por email
- English: send me the CVs, send to my email, can you email them, send CVs to

**Tone:** Helpful, redirecting

**Goal:** Redirect to platform signup instead of sending CVs directly

**Required Elements:**
- Agree enthusiastically ("Claro que sí")
- Explain they need to post vacancy first
- Provide free job posting link
- Frame as benefit ("te los envío directamente por ahí")

**Example (Spanish):**
```
Claro que sí, [Name]. Por favor publica tu vacante directamente en CazVid y te enviaré mis recomendaciones directamente por ahí.

Puedes publicar gratis en: [link]

¿Qué te parece?
```

**Example (English):**
```
Absolutely, [Name]! If you post your job on CazVid, I can send the CVs directly to you through the platform.

Post your job for free here: [link]

Sound good?
```

**Notes:**
- Never refuse the request - always frame as "yes, and..."
- The platform signup is prerequisite, not obstacle

---

### Location Objection (Both Languages)

**Triggers:**
- Spanish: estamos en [city], la vacante es en [city], candidatos de [city], estamos basados en
- English: we are based in, we're located in, looking for candidates in, position is in [city]

**Tone:** Helpful, solution-oriented

**Goal:** Redirect to platform - they post job, we send candidates to their email

**Required Elements:**
- Acknowledge their location
- Confirm we have candidates there
- Redirect to posting job on CazVid
- Promise email delivery of candidates
- Free job posting link

**Example (Spanish):**
```
¡Sin problema, [First Name]! Tenemos candidatos en [location].

Publica tu vacante en CazVid y te enviaremos candidatos de [location] directamente a tu correo.

Publica gratis aquí: [link]
```

**Example (English):**
```
No problem at all, [First Name]! We have candidates in [location].

Post your job on CazVid and we'll send candidates from [location] directly to your email.

Post for free here: [link]
```

**Notes:**
- Extract the location they mention (city, region, state, or country)
- Always be optimistic about having candidates there
- Redirect to platform (same philosophy as CV/Email Request)
- This was previously an EXCLUSION - now we handle it

---

### Location Objection AFTER REJECTION (Variant) - ERR-007

**CRITICAL:** This is DIFFERENT from standard Location Objection. Use when prospect explicitly says our profiles DON'T MEET their requirements.

**Triggers (rejection language):**
- Spanish: no cumplen, no cumplen con el requisito, no son de la zona
- English: don't meet requirements, wrong location, not in [city], don't match

**How to Distinguish:**
| Standard Location Objection | After Rejection (THIS) |
|-----------------------------|------------------------|
| "We are based in Miami" | "Your candidates don't meet our location requirements" |
| Proactive location mention | Reactive rejection of profiles sent |
| They're telling us where | They're saying we FAILED |

**Tone:** Empathetic, brief, probing

**Goal:** Acknowledge the miss FIRST, then ask where they need candidates. NO platform push until we know we can help.

**Required Elements:**
- Brief acknowledgment (match their closing energy)
- Apologize for the miss (tactical empathy)
- Ask which location they need (calibrated question)
- NO LINKS until they confirm we can help

**Example (Spanish):**
```
¡Buen año [First Name]! Lamento que no hayan sido la ubicación correcta. ¿En qué zona necesitas candidatos? Tenemos gente en muchas ciudades.
```

**Example (English):**
```
Happy new year [First Name]! Sorry those weren't the right location. Which area do you need candidates in? We have people in many cities.
```

**What NOT to do:**
```
❌ "Lo bueno es que puedes publicar tu vacante GRATIS en CazVid..."
```
↑ WRONG: Pushing platform after they just rejected our profiles feels tone-deaf

**Follow-up:**
- If they respond with location → THEN use standard Location Objection with link
- If they don't respond → Leave alone, they've moved on

**See:** EC-047 in edge-cases.md for detailed analysis

---

### PDF Request (Both Languages)

**Triggers:**
- Spanish: en PDF, formato PDF, envíame en PDF, mándame el PDF, quiero el PDF, necesito en PDF, los CV, sus CV
- English: in PDF, PDF format, send me PDF, please send PDF, I need PDF, I want PDF, their resumes, pdf resumes

**Detection:** Contains "PDF" or "resume/CV" AND request context (send/enviar/mandar/want/quiero/need/necesito/get/share)

**Tone:** Helpful, action-oriented

**Goal:** Point them to candidate pages we ALREADY sent - they can download PDFs via "Contact Now" button

**Required Elements:**
- Acknowledge request positively
- Explain PDFs are accessible through the candidate pages we sent
- Tell them to click "Contact Now" button
- Include video tutorial showing how
- YouTube tutorial (EN): `https://youtu.be/mldU26l91ZA`
- YouTube tutorial (ES): `https://youtu.be/c0E8sfSFqeM`

**Example (English):**
```
Absolutely, [First Name]! You can access the PDF resumes directly through the CazVid platform.

Just select the "Contact Now" button on the candidate pages I sent you and you can download their PDFs directly.

Here's a quick video to show you how: [video]
```

**Example (Spanish):**
```
¡Claro que sí, [First Name]! Puedes acceder a los PDFs directamente a través de la plataforma CazVid.

Solo selecciona el botón "Contactar Ahora" en las páginas de los candidatos que te envié y podrás descargar sus PDFs directamente.

Aquí te dejo un video rápido que te muestra cómo: [video]
```

**Notes:**
- They already have candidate links - no need to post a new job
- "Contact Now" button is the key action
- Video explains the process visually
- Simple and direct - no extra steps required

---

### LinkedIn Profile Request (Both Languages)

**Triggers:**
- English: linkedin, their linkedin, linkedin profile, linkedin account, verify, verification
- Spanish: linkedin, su linkedin, perfil de linkedin, cuenta de linkedin, verificar

**Detection:** Contains "linkedin" AND request/question context (share/give/send/have/access/verify)

**Tone:** Helpful, reassuring

**Goal:** Point them to candidate pages we ALREADY sent - they can access LinkedIn profiles via "Contact Now" button

**Required Elements:**
- Acknowledge their request positively
- Explain LinkedIn profiles are accessible through the candidate pages we sent
- Tell them to click "Contact Now" button
- Include video tutorial showing how
- YouTube tutorial (EN): `https://youtu.be/mldU26l91ZA`
- YouTube tutorial (ES): `https://youtu.be/c0E8sfSFqeM`

**Example (English):**
```
Absolutely, [First Name]! You can access their LinkedIn profiles directly through the CazVid platform.

Just select the "Contact Now" button on the candidate pages I sent you and you can view their LinkedIn profiles directly.

Here's a quick video to show you how: [video]
```

**Example (Spanish):**
```
¡Claro que sí, [First Name]! Puedes acceder a sus perfiles de LinkedIn directamente a través de la plataforma CazVid.

Solo selecciona el botón "Contactar Ahora" en las páginas de los candidatos que te envié y podrás ver sus perfiles de LinkedIn directamente.

Aquí te dejo un video rápido que te muestra cómo: [video]
```

**Notes:**
- They already have candidate links - no need to post a new job
- "Contact Now" button reveals LinkedIn profile access
- Video explains the process visually
- Reassures them that verification is possible

---

### Language Switch Request (English)

**Triggers:**
- communicate in English
- speak English
- in English please
- English?
- do you speak English
- can you write in English

**Tone:** Friendly, accommodating, business-continuing

**Goal:** Switch to English immediately AND continue the conversation - don't just acknowledge the request.

**Required Elements:**
- Acknowledge request positively
- Switch to English immediately
- Continue business conversation (don't just stop at "sure!")
- Reference their specific vacancy/need if known

**Example:**
```
Of course, [First Name]! Happy to continue in English.

Did any of those candidates look like a good fit for your [Job Title] position?
```

**With known context:**
```
Absolutely, [First Name]! Let's continue in English.

I sent you 3 candidates for your [Job Title] role - which ones caught your attention? I can help you connect with them!
```

**Notes:**
- This is NOT a rejection - they're still interested!
- Always continue the business conversation after switching
- Reference their job/candidates if you have context
- See EC-050 in edge-cases.md for detailed analysis

---

## Exclusion Keywords

Skip messages containing these phrases even if they match triggers:

### Spanish Exclusions
- ~~cerré la vacante / cerré vacante~~ → **NOW HANDLED** (see Vacancy Closed)
- lo estaré revisando / lo revisaré (will review - let them review first)
- soy reclutador freelance (freelance recruiter - wrong target)
- por nuestros recursos (using own resources)
- ~~la vacante es en~~ → **NOW HANDLED** (see Location Objection)
- pero / sin embargo (contains objection - needs manual review)

### English Exclusions
- ~~role was closed / position filled~~ → **NOW HANDLED** (see Vacancy Closed)
- I'll take a look / I'll review (let them review first)
- I'm not a recruiter / I no longer work (wrong target)
- ~~we are based in / we're located in~~ → **NOW HANDLED** (see Location Objection)
- I'm not sure / maybe / let me think (uncertainty - don't push)
- but / however (contains objection - needs manual review)

### BPO/Outsourcing Exclusions (Agency Leads Only) - ERR-006
**CRITICAL:** These companies SELL workers, they don't BUY candidates. NOT our target for Agency Leads.

| Phrase | Why It's BPO |
|--------|--------------|
| BPO company | Direct identifier |
| outsourcing company | Direct identifier |
| provide resources from | They offer workers to clients |
| hub in [country] | Offshore delivery center language |
| offshore staffing | Selling offshore workers |
| nearshore | Selling nearshore workers |
| we offer workers/resources to | Provider language, not buyer |
| cost-effective solutions by providing | BPO value prop language |

**Action:** If Agency Leads conversation contains these → EXCLUDE or clarify they're not our target.
**See:** EC-046 in edge-cases.md for full handling guidance.

### Notes on Converted Exclusions
The following were previously exclusions but are now active response types thanks to Jan's handling patterns:
- **Vacancy Closed**: Instead of skipping, ask about next opportunity
- **Location Objection**: Instead of skipping, offer to find local candidates

---

## Campaign Identification

### Known Campaign IDs

| Campaign Type | IDs |
|---------------|-----|
| Agency Leads | `223998`, `240191` |
| CazVid | Others |

**⚠️ ERR-004 WARNING:** Campaign IDs may return "does not exist" error from API. If this happens:
1. Fetch conversations WITHOUT campaign filter
2. Use content detection (below) as primary method
3. Campaign ID filtering is optional optimization only

### Content Detection (PRIMARY METHOD)

| Campaign | Look for |
|----------|----------|
| Agency Leads | "agency-leads.com", "calendly.com/agency-leads" |
| CazVid | "cazvid.com", "cazvid.app", "candidatos potenciales" |

**Note:** Content detection is more reliable than campaign IDs. Always use as fallback.

---

## Data Sources

| Tag | Source |
|-----|--------|
| `[First Name]` | `correspondentProfile.firstName` |
| `[Sender Last Name]` | `linkedInAccount.lastName` |

---

## Sender Accounts

| ID | Name | Last Name |
|----|------|-----------|
| 93126 | Wesley Bouwmeester | Bouwmeester |
| 94527 | Viviana Rodriguez | Rodriguez |
| 94530 | David Mendoza | Mendoza |
| 94531 | Pedro Alejandro Colunga López | Colunga |
| 94533 | John Acebedo | Acebedo |
| 94534 | Jan Sytze Heegstra | Heegstra |
| 94559 | Juan Fajardo | Fajardo |
| 94853 | Filip Vandamme | Vandamme |
| 96268 | Anthony Squillante | Squillante |
| 96269 | Yuvi Shmul | Shmul |
| 96280 | Asaf Hartenstein | Hartenstein |
| 103961 | Shadai Escalona | Escalona |
| 106125 | Emile Ledaine | Ledaine |
| 118434 | Camila Martinez | Martinez |

---

## Technical Notes

### Session Handling - ERR-005

**⚠️ Stale Conversation ID Warning:** Conversation IDs from previous sessions may return 404 errors.

**Rule:** ALWAYS fetch fresh conversation list at start of each processing run.

| DO | DON'T |
|----|-------|
| Call `get_conversations_v2` fresh each run | Reuse conversation IDs from previous context |
| Use IDs only within same session | Cache IDs across sessions |
| Re-fetch if context was interrupted | Assume old IDs are still valid |

**Why:** Conversation IDs may be session-specific or have TTL. When context carries over from a previous session, IDs become stale.

**Workaround Applied:** If 404 errors occur, fetch fresh conversation list and retry.
