# Process HeyReach Conversations

Process unread HeyReach LinkedIn conversations with **dynamic, personalized responses**.

## IMPORTANT: Follow Templates Closely

**Variation is in WORDING only, not in omitting required elements.** Every response MUST include all required links and CTAs as specified in config.md.

### Message Generation Principles
1. **Match their energy** - Enthusiastic message (!!!) → enthusiastic response
2. **Vary openings** - Don't use "De nada" or "You're welcome" every time
3. **Be conversational** - Write like a real person, not a bot
4. **ALWAYS include required elements** - Links and CTAs are MANDATORY
5. **Personalize** - Reference their context when possible

### CRITICAL GUARDRAILS (Automatic Fail if Violated)
- **NEVER fabricate features** - Don't claim "video profile", "video resume", or any feature not in the template
- **NEVER claim contacting candidates is FREE** - It requires a $50/month subscription
- **NEVER skip required links** - Job posting link and YouTube tutorial are MANDATORY
- **NEVER invent new CTAs** - Use the exact CTA format from config.md
- **When in doubt, use standard template verbatim** - Better safe than creative

### CazVid Pricing (NEVER Misrepresent)
- **FREE:** Posting jobs, browsing candidates, viewing profiles, receiving applications
- **PAID ($50/mo):** Contacting candidates, sending messages, accessing contact info

### What Happens When You Post (Use This, Don't Invent)
- We send job to **top 100 matching candidates**
- Candidates apply → **resumes arrive by email**
- **WRONG:** "We'll automatically match you" / "I can help you find matches" ← We don't manually match

## Pre-Flight Health Check with Auto-Retry

**Before processing, verify MCP tools are available with automatic retry logic.**

MCP connections can be temporarily unavailable due to lazy initialization, connection timeouts, or race conditions. The skill MUST implement automatic retries before failing.

### Retry Protocol

```
Attempt 1: mcp__heyreach__get_all_linked_in_accounts with limit: 1
  ↓ If "No such tool available"
  Wait 2 seconds
  ↓
Attempt 2: mcp__heyreach__get_all_linked_in_accounts with limit: 1
  ↓ If "No such tool available"
  Wait 5 seconds
  ↓
Attempt 3: mcp__heyreach__get_all_linked_in_accounts with limit: 1
  ↓ If "No such tool available"
  FAIL with MCP_ERROR
```

### Implementation Steps

1. **Attempt lightweight health check** using `get_all_linked_in_accounts` (smaller response than conversations)

2. **On success**: Log "✓ MCP connection verified" and proceed

3. **On "No such tool available" error**:
   - Log the attempt number and wait time
   - Wait using: `timeout /t N /nobreak >nul 2>&1 || sleep N` (cross-platform)
   - Retry up to 3 total attempts

4. **After 3 failed attempts**:
   - Log error as MCP_ERROR in run log
   - Create error registry entry
   - Inform user: "MCP tools unavailable after 3 retries. Please restart Claude Code session and try again."
   - Do NOT proceed with processing

### Run Log Format for Health Check

```markdown
## Pre-Flight Check

| Attempt | Result | Wait |
|---------|--------|------|
| 1 | ✓ Connected | - |

MCP Status: **CONNECTED**
```

Or if retries were needed:

```markdown
## Pre-Flight Check

| Attempt | Result | Wait |
|---------|--------|------|
| 1 | ✗ Tool unavailable | 2s |
| 2 | ✗ Tool unavailable | 5s |
| 3 | ✓ Connected | - |

MCP Status: **CONNECTED** (after 2 retries)
```

## Run Modes

Ask the user which mode to run:

| Mode | Description |
|------|-------------|
| **Live** | Send messages (default) |
| **Dry-Run** | Preview messages without sending - shows exactly what would be sent |

In **Dry-Run mode**:
- Perform all analysis and generate messages
- Display each message with recipient and content
- Do NOT call `send_message`
- End with summary: "Dry-run complete. X messages would be sent."

## Instructions

1. Read the configuration from `config.md` to get:
   - FETCH_LIMIT and MAX_MESSAGES_TO_SEND
   - LEAD_SAMPLE_1, LEAD_SAMPLE_2, LEAD_SAMPLE_3
   - **Response Guidelines** (NOT templates - generate fresh each time)
   - Already Processed Detection patterns

2. Ask the user which response type to process:
   - **CazVid Thank-You** - Spanish/English "gracias" or "thanks"
   - **CazVid Info Request** - Spanish/English asking how it works
   - **Agency Leads Decline** - "not interested" or "no thanks"
   - **Agency Leads Sample Request** - Leads wanting the 3 lead sample
   - **All Standard Responses** - Process all types in one run

3. Ask how many messages to send (suggest MAX_MESSAGES_TO_SEND as default)

4. Fetch unread conversations:
   ```
   mcp__heyreach__get_conversations_v2 with seen: false, limit: FETCH_LIMIT
   ```

5. Filter conversations:
   - Check `lastMessageSender == "CORRESPONDENT"`
   - Match trigger phrases from config.md
   - Apply exclusion keywords
   - Stop once you have enough qualifying candidates

6. For each qualifying conversation (up to MAX_MESSAGES_TO_SEND):

   a. **Get conversation details** with `mcp__heyreach__get_chatroom`

   b. **Check if already processed** - Look through messages where `sender == "ME"`:
      - Use the "Already Processed Detection" patterns from config.md
      - If any match, SKIP this conversation

   c. **Verify campaign type**:
      - Known Agency Leads IDs: `223998`, `240191`
      - Or check for "agency-leads.com" vs "cazvid.com" links

   d. **Analyze context for personalization**:
      - firstName from `correspondentProfile.firstName`
      - senderLastName from `linkedInAccount.lastName`
      - Their message tone (enthusiastic? brief? formal?)
      - Any specific context they mentioned

   e. **Generate dynamic message**:
      - Follow Response Guidelines for this type
      - Match their energy level
      - Vary your opening phrase
      - Include ALL required elements (links, CTAs)
      - Make it feel personal and human

   f. **Send message** using `mcp__heyreach__send_message`

7. Report results:
   - Total conversations fetched
   - Number qualifying after filtering
   - Number skipped (already processed)
   - **Live mode:** Number of messages sent + names of leads messaged
   - **Dry-run mode:** Number of messages that WOULD be sent + preview table

## Response Types Quick Reference

| Type | Triggers | Skip If Already Sent |
|------|----------|----------------------|
| CazVid Thank-You (ES) | gracias | "De nada" + "share.cazvid.app" |
| CazVid Thank-You (EN) | thanks, thank you | "You're welcome" + "share.cazvid.app" |
| CazVid Info Request (ES) | cómo funciona | "$50 USD" |
| CazVid Info Request (EN) | how does it work | "$50 USD/month" |
| Agency Leads Decline | not interested, no thanks | "timing, fit, or need" |
| Agency Leads Sample | send me, yes please | "Here's your 3 lead sample" |

## Exclusion Keywords (Always Skip)

**Spanish:** cerré la vacante, lo estaré revisando, soy reclutador freelance, por nuestros recursos, pero

**English:** role was closed, I'll take a look, I'm not a recruiter, I no longer work, we are based in, I'm not sure, but

## Run Logging

Create a run log at `training/run-logs/YYYY-MM-DD_HH-MM_process-N.md` with:
- Fetch results
- Processing log (table of leads, triggers, actions)
- Final summary (sent, skipped, errors)

## Error Handling

When errors occur:

1. **Log immediately** in the run log's "Errors Encountered" table
2. **Categorize** the error:
   - `API_ERROR` - HeyReach API issues
   - `OVERFLOW_ERROR` - Response too large
   - `CONFIG_ERROR` - Config file issues
   - `TEMPLATE_ERROR` - Template substitution failed
   - `MCP_ERROR` - MCP tool unavailable
3. **Add to error registry** (`training/error-registry.md`):
   - Assign next ERR-XXX number
   - Set status = OPEN
   - Link to this run log
4. **Attempt recovery** if possible:
   - API errors: Retry after 3 seconds
   - Overflow: Reduce limit and retry
   - MCP errors: Retry once
5. **If unrecoverable**, complete run log and notify user to run `/troubleshoot`

### Common Errors & Quick Fixes

| Error | Quick Fix |
|-------|-----------|
| "Limit must be between 1 and 100" | Reduce FETCH_LIMIT in config.md |
| "result exceeds maximum allowed tokens" | Use limit=10 in API call |
| "No such tool available" | Auto-retry with backoff (2s, then 5s) - see Pre-Flight Check |
| Template shows `[First Name]` literally | Check correspondentProfile.firstName exists |
